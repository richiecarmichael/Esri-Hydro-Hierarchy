﻿using ESRI.ArcGIS.Framework;
using System;
using System.Windows;

namespace ExportHydroNetwork {
    public class Button1 : ESRI.ArcGIS.Desktop.AddIns.Button {
        private Window _window = null;

        public Button1() {        }
        protected override void OnClick() {
            try {
                if (this._window == null) {
                    // Get the ArcMap Window Position
                    IWindowPosition windowPosition = (IWindowPosition)ArcMap.Application;

                    // Create a new window
                    this._window = new HydroWindow();
                    this._window.Left = windowPosition.Left + (windowPosition.Width / 2) - (this._window.Width / 2);
                    this._window.Top = windowPosition.Top + (windowPosition.Height / 2) - (this._window.Height / 2);
                    this._window.Closing += (s, e) => {
                        e.Cancel = true;
                        this._window.Hide();
                    };
                    this._window.Show();
                }
                else {
                    if (this._window.IsVisible) {
                        this._window.Hide();
                    }
                    else {
                        this._window.Show();
                    }
                }
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message + Environment.NewLine + ex.StackTrace);
            }
        }
    }

}
